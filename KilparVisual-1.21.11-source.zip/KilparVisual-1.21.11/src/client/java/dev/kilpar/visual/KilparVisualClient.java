package dev.kilpar.visual;

import com.mojang.blaze3d.platform.InputConstants;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public final class KilparVisualClient implements ClientModInitializer {
    public static final String MOD_ID = "kilparvisual";
    private static KeyMapping openMenu;
    private static int trailTicks = 0;

    @Override
    public void onInitializeClient() {
        KilparConfig.load();
        KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.kilparvisual.open_menu", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (KilparConfig.trails && client.player != null && client.level != null && ++trailTicks % 3 == 0) {
                var p = client.player;
                client.level.addParticle(ParticleTypes.END_ROD, p.getX(), p.getY() + 0.08, p.getZ(), 0.0, 0.015, 0.0);
            }
            while (openMenu.consumeClick()) {
                if (client.screen == null) client.setScreen(new KilparScreen());
                else if (client.screen instanceof KilparScreen) client.setScreen(null);
            }
        });
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath(MOD_ID, "overlay"), KilparVisualClient::renderHud);
        Runtime.getRuntime().addShutdownHook(new Thread(KilparConfig::save, "KilparVisual-config-save"));
    }

    private static void renderHud(GuiGraphics g, net.minecraft.client.DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        int color = KilparConfig.accent;
        if (KilparConfig.crosshair) {
            int cx = mc.getWindow().getGuiScaledWidth() / 2;
            int cy = mc.getWindow().getGuiScaledHeight() / 2;
            g.fill(cx - 5, cy, cx - 2, cy + 1, color);
            g.fill(cx + 2, cy, cx + 5, cy + 1, color);
            g.fill(cx, cy - 5, cx + 1, cy - 2, color);
            g.fill(cx, cy + 2, cx + 1, cy + 5, color);
        }

        g.pose().pushMatrix();
        g.pose().translate(KilparConfig.hudX, KilparConfig.hudY);
        g.pose().scale(KilparConfig.hudScale, KilparConfig.hudScale);
        int y = 0;
        if (KilparConfig.watermark) {
            g.fill(0, 0, 112, 18, 0xB8181824);
            g.fill(0, 0, 2, 18, color);
            g.drawString(mc.font, Component.literal("KILPAR  /  VISUAL"), 8, 5, 0xFFFFFFFF, false);
            y = 23;
        }
        if (KilparConfig.selfNametag) {
            g.drawString(mc.font, mc.player.getName(), 0, y, 0xFFFFFFFF, true);
            y += 12;
        }
        if (KilparConfig.armorHud) {
            g.fill(0, y, 92, y + 16, 0xB8181824);
            g.drawString(mc.font, Component.literal("ARMOR  " + mc.player.getArmorValue()), 6, y + 4, color, false);
            y += 21;
        }
        if (KilparConfig.potions) {
            int effects = mc.player.getActiveEffects().size();
            g.fill(0, y, 92, y + 16, 0xB8181824);
            g.drawString(mc.font, Component.literal("EFFECTS  " + effects), 6, y + 4, 0xFFFFFFFF, false);
            y += 21;
        }
        if (KilparConfig.hotkeys) {
            g.fill(0, y, 112, y + 16, 0xB8181824);
            g.drawString(mc.font, Component.literal("MENU  RIGHT SHIFT"), 6, y + 4, 0xFFB9B5C9, false);
        }
        g.pose().popMatrix();

        if (KilparConfig.targetHud && mc.hitResult instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity target && target.isAlive()) {
            int x = mc.getWindow().getGuiScaledWidth() / 2 + 12;
            int targetHudY = mc.getWindow().getGuiScaledHeight() / 2 + 12;
            g.fill(x, targetHudY, x + 126, targetHudY + 34, 0xD0181824);
            g.fill(x, targetHudY, x + 2, targetHudY + 34, color);
            g.drawString(mc.font, target.getDisplayName(), x + 8, targetHudY + 6, 0xFFFFFFFF, false);
            String health = String.format(java.util.Locale.ROOT, "%.1f / %.1f HP", target.getHealth(), target.getMaxHealth());
            g.drawString(mc.font, Component.literal(health), x + 8, targetHudY + 19, color, false);
        }
    }
}
