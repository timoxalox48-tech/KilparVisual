# Kilpar Visual — Minecraft 1.21.11 / Fabric

Lightweight client-only Fabric project. Java 21, official Mojang mappings, Fabric Loader 0.18.1 and Fabric API 0.141.1+1.21.11.

## Implemented (real functionality)

### Visuals
- **Crosshair** — minimal four-segment crosshair with configurable accent color.
- **Self Nametag** — draws the local player's name in the HUD.
- **Trails** — emits a small client-side End Rod particle trail behind the local player. It is cosmetic and sends no movement or combat packets.
- **TargetHUD** — shows the name and health of the living entity currently under the crosshair. It does not search through walls or reveal hidden entities.

### HUD
- **Watermark** — Kilpar Visual label.
- **ArmorHUD** — displays the player's current armor value.
- **Potions** — displays the number of active status effects.
- **Hotkeys** — displays the menu hotkey.
- HUD origin and scale are adjustable in the HUD tab; accent color is adjustable in Visuals.

### Utilities
- No utility from the requested list is included in this build. The remaining items were not replaced with unrelated features or fake toggles.

## Deliberately omitted

Block Overlay, China Hat, Aspect Ratio, full entity ESP, Custom Sky, Body Glow, Shift Tab, detailed cooldown/item/effect panels, Item Scroller, Slot Lock, Free Look, Auto Eat, Auto Potion, Auto Leave/PvP Saver, Auto Reconnect/Respawn, RW Joiner and Waypoints are not claimed as implemented. Some require additional rendering/mixin work or server-/protocol-specific behavior; they are omitted rather than shipped as inert switches. TargetHUD is limited to the entity already selected by the vanilla crosshair raycast.

## Build

Requirements: JDK 21 and Gradle 9.2.1 (or a compatible Gradle 9.x release).

```bash
gradle build
```

The remapped mod artifact is written to `build/libs/KilparVisual-1.21.11-1.0.0.jar`.

## Install

1. Install Fabric Loader for Minecraft Java Edition 1.21.11.
2. Install the matching Fabric API for 1.21.11.
3. Copy the built JAR into `.minecraft/mods`.
4. Launch the Fabric 1.21.11 profile.
5. Press **Right Shift** to open/close the menu.

Settings are saved to `.minecraft/config/kilparvisual.properties`.

## Verification status

The source and metadata target Minecraft 1.21.11. This environment did not have Gradle installed and could not reach external dependency repositories, so the project could not be compiled or launched here. Consequently no loadable JAR is included and no in-game test is claimed. Build and runtime verification must be completed in an environment with Gradle and dependency access.
