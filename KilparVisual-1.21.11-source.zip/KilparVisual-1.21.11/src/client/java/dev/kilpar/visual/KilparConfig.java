package dev.kilpar.visual;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Small, synchronous config: writes happen only on user interaction / shutdown. */
public final class KilparConfig {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("kilparvisual.properties");
    private static final Properties P = new Properties();

    public static boolean watermark = true;
    public static boolean crosshair = true;
    public static boolean selfNametag = false;
    public static boolean trails = false;
    public static boolean targetHud = false;
    public static boolean armorHud = true;
    public static boolean potions = true;
    public static boolean hotkeys = true;
    public static int accent = 0xFF8B7CFF;
    public static int hudX = 8;
    public static int hudY = 8;
    public static float hudScale = 1.0f;

    private KilparConfig() {}

    public static void load() {
        if (!Files.isRegularFile(FILE)) return;
        try (InputStream in = Files.newInputStream(FILE)) {
            P.load(in);
            watermark = bool("watermark", watermark);
            crosshair = bool("crosshair", crosshair);
            selfNametag = bool("selfNametag", selfNametag);
            trails = bool("trails", trails);
            targetHud = bool("targetHud", targetHud);
            armorHud = bool("armorHud", armorHud);
            potions = bool("potions", potions);
            hotkeys = bool("hotkeys", hotkeys);
            accent = integer("accent", accent);
            hudX = integer("hudX", hudX);
            hudY = integer("hudY", hudY);
            hudScale = Math.max(0.5f, Math.min(2.0f, decimal("hudScale", hudScale)));
        } catch (IOException ignored) { }
    }

    private static boolean bool(String key, boolean fallback) { return Boolean.parseBoolean(P.getProperty(key, Boolean.toString(fallback))); }
    private static int integer(String key, int fallback) {
        try { return Integer.decode(P.getProperty(key, Integer.toString(fallback))); }
        catch (RuntimeException ex) { return fallback; }
    }
    private static float decimal(String key, float fallback) {
        try { return Float.parseFloat(P.getProperty(key, Float.toString(fallback))); }
        catch (RuntimeException ex) { return fallback; }
    }

    public static void save() {
        Properties out = new Properties();
        out.setProperty("watermark", Boolean.toString(watermark));
        out.setProperty("crosshair", Boolean.toString(crosshair));
        out.setProperty("selfNametag", Boolean.toString(selfNametag));
        out.setProperty("trails", Boolean.toString(trails));
        out.setProperty("targetHud", Boolean.toString(targetHud));
        out.setProperty("armorHud", Boolean.toString(armorHud));
        out.setProperty("potions", Boolean.toString(potions));
        out.setProperty("hotkeys", Boolean.toString(hotkeys));
        out.setProperty("accent", String.format("0x%08X", accent));
        out.setProperty("hudX", Integer.toString(hudX));
        out.setProperty("hudY", Integer.toString(hudY));
        out.setProperty("hudScale", Float.toString(hudScale));
        try {
            Files.createDirectories(FILE.getParent());
            try (OutputStream stream = Files.newOutputStream(FILE)) {
                out.store(stream, "Kilpar Visual settings");
            }
        } catch (IOException ignored) { }
    }
}
