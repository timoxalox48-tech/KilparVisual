package dev.kilpar.visual;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class KilparScreen extends Screen {
    private enum Tab { VISUALS, HUD, UTILITIES }
    private Tab tab = Tab.VISUALS;
    private int left, top;
    private static final int PANEL_W = 360, PANEL_H = 300;

    public KilparScreen() { super(Component.literal("Kilpar Visual")); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        // Avoid the vanilla background blur pass: Minecraft 1.21.11 permits
        // only one blur operation per frame, and this screen must not request it.
        g.fill(0, 0, width, height, 0x90000000);
        left = (width - PANEL_W) / 2;
        top = (height - PANEL_H) / 2;
        g.fill(left, top, left + PANEL_W, top + PANEL_H, 0xF0141420);
        g.fill(left, top, left + PANEL_W, top + 2, KilparConfig.accent);
        g.drawString(font, "KILPAR", left + 18, top + 16, 0xFFFFFFFF, false);
        g.drawString(font, "VISUAL CLIENT  /  1.21.11", left + 84, top + 17, 0xFF858397, false);

        drawTab(g, "Visuals", Tab.VISUALS, left + 16, top + 43, mouseX, mouseY);
        drawTab(g, "HUD", Tab.HUD, left + 128, top + 43, mouseX, mouseY);
        drawTab(g, "Utilities", Tab.UTILITIES, left + 240, top + 43, mouseX, mouseY);
        g.fill(left + 16, top + 72, left + PANEL_W - 16, top + 73, 0xFF343342);

        if (tab == Tab.VISUALS) {
            row(g, "Crosshair", KilparConfig.crosshair, 0, mouseX, mouseY);
            row(g, "Self Nametag", KilparConfig.selfNametag, 1, mouseX, mouseY);
            row(g, "Trails", KilparConfig.trails, 2, mouseX, mouseY);
            row(g, "TargetHUD", KilparConfig.targetHud, 3, mouseX, mouseY);
            action(g, "Accent color  /  click to cycle", 4, mouseX, mouseY);
        } else if (tab == Tab.HUD) {
            row(g, "Watermark", KilparConfig.watermark, 0, mouseX, mouseY);
            row(g, "ArmorHUD", KilparConfig.armorHud, 1, mouseX, mouseY);
            row(g, "Potions", KilparConfig.potions, 2, mouseX, mouseY);
            row(g, "Hotkeys", KilparConfig.hotkeys, 3, mouseX, mouseY);
            action(g, "HUD X  click left / right", 4, mouseX, mouseY);
            action(g, "HUD Y  click left / right", 5, mouseX, mouseY);
            action(g, "HUD Scale  click left / right", 6, mouseX, mouseY);
        } else {
            g.drawString(font, "No safe, fully implemented utility is enabled.", left + 28, top + 103, 0xFFB7B5C5, false);
            g.drawString(font, "Restricted or server-dependent items are omitted.", left + 28, top + 120, 0xFF777587, false);
        }
        g.drawString(font, "RIGHT SHIFT  ·  CLOSE", left + 18, top + PANEL_H - 22, 0xFF777587, false);
        super.render(g, mouseX, mouseY, delta);
    }

    private void drawTab(GuiGraphics g, String label, Tab value, int x, int y, int mx, int my) {
        boolean active = tab == value;
        boolean hover = inside(mx, my, x, y, 100, 22);
        int bg = active ? 0xFF302C45 : hover ? 0xFF242432 : 0x00000000;
        if (bg != 0) g.fill(x, y, x + 100, y + 22, bg);
        g.drawCenteredString(font, label, x + 50, y + 7, active ? KilparConfig.accent : 0xFFB8B6C6);
    }

    private void row(GuiGraphics g, String label, boolean enabled, int index, int mx, int my) {
        int y = top + 86 + index * 31;
        g.drawString(font, label, left + 28, y + 7, 0xFFE6E4EF, false);
        int x = left + PANEL_W - 76;
        boolean hover = inside(mx, my, x, y, 48, 22);
        g.fill(x, y, x + 48, y + 22, enabled ? KilparConfig.accent : (hover ? 0xFF3A3949 : 0xFF292936));
        g.drawCenteredString(font, enabled ? "ON" : "OFF", x + 24, y + 7, enabled ? 0xFF171522 : 0xFFB9B7C7);
    }

    private void action(GuiGraphics g, String label, int index, int mx, int my) {
        int y = top + 210 + (index - 4) * 26;
        int x = left + 20;
        boolean hover = inside(mx, my, x, y, PANEL_W - 40, 22);
        g.fill(x, y, x + PANEL_W - 40, y + 22, hover ? 0xFF302F40 : 0xFF22222F);
        g.drawString(font, label, x + 9, y + 7, 0xFFD3D1DF, false);
        if (index == 4 && tab == Tab.VISUALS) g.fill(x + PANEL_W - 58, y + 5, x + PANEL_W - 48, y + 15, KilparConfig.accent);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubled) {
        if (event.button() != 0) return super.mouseClicked(event, doubled);
        int mx = (int) event.x(), my = (int) event.y();
        if (inside(mx, my, left + 16, top + 43, 100, 22)) tab = Tab.VISUALS;
        else if (inside(mx, my, left + 128, top + 43, 100, 22)) tab = Tab.HUD;
        else if (inside(mx, my, left + 240, top + 43, 100, 22)) tab = Tab.UTILITIES;
        else if (tab == Tab.VISUALS) {
            if (inside(mx, my, left + PANEL_W - 76, top + 86, 48, 22)) KilparConfig.crosshair = !KilparConfig.crosshair;
            else if (inside(mx, my, left + PANEL_W - 76, top + 117, 48, 22)) KilparConfig.selfNametag = !KilparConfig.selfNametag;
            else if (inside(mx, my, left + PANEL_W - 76, top + 148, 48, 22)) KilparConfig.trails = !KilparConfig.trails;
            else if (inside(mx, my, left + PANEL_W - 76, top + 179, 48, 22)) KilparConfig.targetHud = !KilparConfig.targetHud;
            else if (inside(mx, my, left + 20, top + 210, PANEL_W - 40, 22)) {
                int[] colors = {0xFF8B7CFF, 0xFF64D8C8, 0xFFFF8E9E, 0xFFFFC56E, 0xFF75B7FF};
                int next = 0;
                for (int i = 0; i < colors.length; i++) if (colors[i] == KilparConfig.accent) next = (i + 1) % colors.length;
                KilparConfig.accent = colors[next];
            }
        } else if (tab == Tab.HUD) {
            int y = top + 86;
            if (inside(mx, my, left + PANEL_W - 76, y, 48, 22)) KilparConfig.watermark = !KilparConfig.watermark;
            else if (inside(mx, my, left + PANEL_W - 76, y + 31, 48, 22)) KilparConfig.armorHud = !KilparConfig.armorHud;
            else if (inside(mx, my, left + PANEL_W - 76, y + 62, 48, 22)) KilparConfig.potions = !KilparConfig.potions;
            else if (inside(mx, my, left + PANEL_W - 76, y + 93, 48, 22)) KilparConfig.hotkeys = !KilparConfig.hotkeys;
            else if (inside(mx, my, left + 20, y + 124, PANEL_W - 40, 22)) KilparConfig.hudX += mx < left + PANEL_W / 2 ? -2 : 2;
            else if (inside(mx, my, left + 20, y + 150, PANEL_W - 40, 22)) KilparConfig.hudY += mx < left + PANEL_W / 2 ? -2 : 2;
            else if (inside(mx, my, left + 20, y + 176, PANEL_W - 40, 22)) KilparConfig.hudScale = Math.max(0.5f, Math.min(2.0f, KilparConfig.hudScale + (mx < left + PANEL_W / 2 ? -0.1f : 0.1f)));
        }
        KilparConfig.save();
        return true;
    }

    private static boolean inside(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
